### 21.22 ###
 * Javascript fixes
 
### 21.21 ###
 * Minor fixes
 
### 21.20 ###
 * Minor fixes
 
### 21.19 ###
 * Minor fixes
 
### 21.18 ###
 * Minor fixes
 
### 21.17 ###
 * Improved javascript and css
 * Minor fixes

### 21.16 ###
 * Improved Flash helper
 * Minor fixes

### 21.12 ###
 * Maintenance update

### 21.9 ###
 * Minor fixes
 * Next Major release version (22) will offer full HTML/JS version.
   Flash Admin and Teachers  will be able to continue with the Flash version but
   Students will have to connect with the Flash version too.

### 21.6 ###
 * Add Desktop Student Helper javascript for users without Flash plugin available
 * Code preparation for next release accepting HTML5 version of the Student liveroom